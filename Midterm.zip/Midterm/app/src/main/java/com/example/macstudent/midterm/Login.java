package com.example.macstudent.midterm;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class Login extends AppCompatActivity {

//    private ImageView i1;
//    private ImageView i2;
//    private ImageView i3;
//    private ImageView i4;
//    private ImageView i5;
//    private ImageView i6;
//    private ImageView i7;
//    private ImageView i8;
//    private ImageView i9;
//    private Button button;
 CheckBox checkBox;
////    private ImageView i10;
//    private AlertDialog alertDialog;
    ArrayList<String> images = new ArrayList<>();







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

       ImageView i1 = findViewById(R.id.imageView1);
       ImageView i2 = findViewById((R.id.imageView2));
       ImageView i3 = findViewById(R.id.imageView3);
       ImageView i4 = findViewById(R.id.imageView4);
       ImageView i5 = findViewById(R.id.imageView5);
        ImageView i6  = findViewById(R.id.imageView6);
        ImageView  i7 = findViewById(R.id.imageView7);
        ImageView  i8 = findViewById(R.id.imageView8);
        ImageView  i9 = findViewById(R.id.imageView9);
     Button button = findViewById(R.id.buttontoverify);
         checkBox = findViewById(R.id.checkBox);
        ImageView  i10 = findViewById(R.id.refresh);



    }




    public void verification(View view){
        if (checkBox.isChecked())
        {
            if (images.contains("image1")&& images.contains("image2") && images.contains("image3") && images.contains("image4")&& images.size()==4)
            {
                Alert("YOU ARE RIGHT","Login Success");
            }
            else
            {
                Alert("wrong images selected","login failed");
            }
        }
        else
        {
            Alert("please check the Box!","login failed");
        }

    }

    public void Alert(String msg, final String title) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(msg)
                .setCancelable(false)
                .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(Login.this, title, Toast.LENGTH_SHORT).show();

                    }
                });
    }

    public void fade(View view) {
        ImageView faded = (ImageView) view;


        faded.animate().alpha(0.50f).setDuration(300);
        faded.setImageResource(R.drawable.checked);
        int tag = Integer.parseInt(faded.getTag().toString());

        if (tag == 1)
            faded.setBackgroundResource(R.drawable.img1);
        else if(tag == 2)
            faded.setBackgroundResource(R.drawable.img2);
        else if(tag == 3)
            faded.setBackgroundResource(R.drawable.img3);
        else if(tag == 4)
            faded.setBackgroundResource(R.drawable.img4);
        else if(tag== 5)
            faded.setBackgroundResource(R.drawable.img5);
        else if(tag==6)
            faded.setBackgroundResource(R.drawable.img6);
        else if(tag == 7)
            faded.setBackgroundResource(R.drawable.img7);
        else if(tag == 8)
            faded.setBackgroundResource(R.drawable.img8);
        else if(tag == 9)
            faded.setBackgroundResource(R.drawable.img9);

        String imgname = "image" + tag;
        images.add(imgname);

    }
    public void alert(final String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message).setCancelable(false).setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(Login.this, message, Toast.LENGTH_SHORT).show();

            }
        });
        AlertDialog Alert = builder.create();
        Alert.show();
    }

//    public void verifyClicked(View view) {
//        if(checkBox.isChecked()){
//
//            alert("Login Verified");
//        }else {
//            alert("please select the checkbox");
//        }
    }




